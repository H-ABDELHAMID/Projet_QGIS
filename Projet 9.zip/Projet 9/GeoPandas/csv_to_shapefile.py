# -*- coding: utf-8 -*-
"""
Created on Tue Nov 30 21:01:22 2021

@author: hp
"""


import pandas as pd
import geopandas as gpd

##  -- Lire le fichier '.csv' avec le module pandas

data_CV = pd.read_csv('DataCenter.csv')

##  -- Creer un geodataframe en utilisant pandas dataframe 

data_gdf = gpd.GeoDataFrame(data_CV , geometry = gpd.points_from_xy(data_CV['Y'],data_CV['X'] ))
data_gdf.plot(markersize = 2 ,figsize = (10,15))

## -- Obtenir le ESRI_WKT

WKT_ESRI = 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["Degree",0.017453292519943295]]'

##  -- Sauvegarder le fichier csv en un fichier d'extension .shp .

data_gdf.to_file( filename= 'Centre_Vacc.shp' ,driver = 'ESRI Shapefile', crs_wkt = WKT_ESRI ) 

#generation de quatres fichiers
