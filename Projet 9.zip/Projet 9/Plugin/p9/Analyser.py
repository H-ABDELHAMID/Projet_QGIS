import csv
from qgis.core import QgsVectorLayer , QgsFeature , QgsField, QgsGeometry , QgsProject
from qgis.PyQt.QtCore import QVariant 


class Analyser:
    data = []
    def __init__(self):

        pass
    def loadFile(self, filename):

        with open(filename, encoding='cp1252') as csv_file:                                         # -- Ouvrir le fichier a convertir
            csv_reader = csv.reader(csv_file, delimiter=',',quotechar='"')
            next(csv_reader, None)

            for row in csv_reader:                                                                   # -- Parcourir le fichier et stocke les infos dans une liste
                self.data.append(
                    [row[0],row[1],row[2]]
                )
           
    def createLayer(self, name):

        vl = QgsVectorLayer("point?crs=epsg:4326",name,"memory")                   # -- Utiliser un type de codage WGS 84, et prendre le nom a affiche dans le Layer
        pr = vl.dataProvider()
        pr.addAttributes([QgsField('nom', QVariant.String),
        QgsField('X', QVariant.String),QgsField('Y', QVariant.String)               # -- Ajouter dans la table d'attribut les donnees deja extrait du fichier
        ])
        
        vl.updateFields()

        for d in self.data:                                                         # -- Parcourir la liste

            fet = QgsFeature()

            fet.setGeometry(QgsGeometry.fromWkt("POINT(%s %s)" % (d[2],d[1])))              # -- Convertion des coordonnes(X,Y) en des donnees spatiales
            fet.setAttributes([d[0],d[2],d[1] ])                                            
            pr.addFeatures([fet])

        vl.updateExtents()
        QgsProject.instance().addMapLayer(vl)
          